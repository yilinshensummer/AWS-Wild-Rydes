window._config = {
    cognito: {
        userPoolId: 'us-west-2_lcWeIjwMf', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '8rndmrbsmfadqqtvafm90srj', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-west-2' // e.g. us-west-2
    },
    api: {
        invokeUrl: 'https://te68s8jurh.execute-api.us-west-2.amazonaws.com/prod' // e.g. https://ttf5alun5d.execute-api.us-west-2.amazonaws.com/prod
    }
};
